# 🧠 AI Translator Rule List - Release 6 (The Mod Update)
[![License: CC BY-NC 4.0](https://img.shields.io/badge/License-CC%20BY--NC%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc/4.0/)

This project contains a rule-based AI translation system. **Release 6** introduces a dedicated **Modding System**, allowing users to install custom tools without risking the core system stability.

---

## 🆕 What's New in Release 6?
* **The Mod Zone (Rules 31-40):** A reserved block of rules specifically for user-created mods, debug tools, and custom scripts.
* **Mod Installer (`/install`):** A new developer command to easily write code into the Mod Zone.
* **Mod Manager (`/mods`):** A command to list all currently active mods.
* **Holiday Cleanup:** The system has been reset from the holiday events (Thanksgiving/Christmas), returning Rule 26 to a placeholder state.

---

## ⚙️ Official Rule Roadmap
The system rules are now strictly partitioned to prevent conflicts:

| Rule Range | Purpose | Status |
| :--- | :--- | :--- |
| **1 - 30** | **Core Systems** | Protected (Translation logic, Holiday events, Kernel) |
| **31 - 40** | **The Mod Zone** | **Open** (Reserved for User Mods & Custom Rules) |
| **41 - 98** | **Expansion** | Open (Available for future core features) |
| **99 - ∞** | **Achievements** | Protected (Persistent user achievements) |

---

## 🛠️ Command Reference

### Modding Commands (New!)
| Command | Function |
| :--- | :--- |
| **`/install <slot> <text>`** | (Rule 42) Installs a custom rule into a specific slot (31-40 only). |
| **`/mods`** | (Rule 41) Lists all currently installed mods in the Mod Zone. |
| **`/debug`** | (Rule 31 Mod) *Optional:* Displays a raw system diagnostic if the Debug Mod is installed. |

### Core Translation Commands
| Command | Function |
| :--- | :--- |
| **`/lang4 <language>`** | Adds a new language to the system. |
| **`/lang4 to <language>`** | Sets the active "translate to" language. |
| **`/lang4 list`** | Lists all currently known languages. |
| **`/explain=0` / `/explain=1`** | Toggles the English Explanation section on/off. |
| **`/version`** | Displays the current loaded file version. |

---

## 🏆 Achievements
This system tracks user milestones across updates.
* **Standard Achievements:** Rules 100-103 (Halloween, Thanksgiving, Christmas, Developer Mode).
* **Anti-Cheat:** New update files do *not* contain past achievement rules. You only keep them if you were present for the event!

---

© wesleys4812