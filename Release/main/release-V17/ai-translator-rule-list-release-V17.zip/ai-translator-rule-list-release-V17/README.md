## 🆕 New Commands

- `/lang4 id <text>` — Identifies the input language or provides definitions, translations, and root etymology for words/phrases (Rule 64).
- `/help` — Displays a categorized menu of standard user commands (Rule 65).
- `/info` — Triggers the standardized system diagnostic status block (Introduced in V15 / Integrated in V16 Rule 4).